package com.benum;

public enum Category {
	FICTION,SCIENCE,TECHNOLOGY,PROGRAMING,YOGA,COMIC
}
