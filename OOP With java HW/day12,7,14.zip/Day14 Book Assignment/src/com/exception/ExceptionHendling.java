package com.exception;

public class ExceptionHendling extends Exception {
	public ExceptionHendling(String msg) {
		super(msg);
	}
}
