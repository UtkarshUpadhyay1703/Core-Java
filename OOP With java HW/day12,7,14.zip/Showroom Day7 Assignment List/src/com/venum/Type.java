package com.venum;

public enum Type {
	SADAN,SUV,HATCHBACK
}
