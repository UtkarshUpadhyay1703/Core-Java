package exceptionHendling;

public class ExceptionHandler extends Exception{
	public ExceptionHandler(String Msg) {
		super(Msg);
	}
}
