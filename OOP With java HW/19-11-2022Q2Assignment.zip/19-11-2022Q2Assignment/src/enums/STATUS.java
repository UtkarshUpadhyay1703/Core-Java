package enums;

public enum STATUS {
	PENDING, PROGRESS, COMPLETED
}
