package tester;

import static reader.Reader.dateMaxWithdraw;
import static reader.Reader.maxDeposite;
import static reader.Reader.shoppingExpenses;
import static reader.Reader.sumDeposits;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) throws IOException {
		try(Scanner sc = new Scanner(System.in))  {
			String option;
			do {
				System.out
						.println("Enter option Display following details on the console:\n" + "A.Sum of all deposits\n"
								+ "B.Max deposit amount\n C.Shopping expenses (sum of withdrawals for shopping)\n"
								+ "D.Date on which maximum amount withdrawn, E. For Exit");
			
				option=sc.next();
				System.out.println(option);
				switch (option) {
				case "A":
					sumDeposits();
					break;
				case "B":
					maxDeposite();
					break;
				case "C":
					shoppingExpenses();
					break;
				case "D":
					dateMaxWithdraw();
					break;
				}
			} while (option != "F");
			System.out.println("End of While");
			}catch (NoSuchElementException e) {
			e.printStackTrace();
		}
	}
}
